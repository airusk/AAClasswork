// const Util = { 
  
export function uniqueId() {
    return new Date().getTime();
  }

// }
// export default Util;