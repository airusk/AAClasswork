class StaticPagesController < ApplicationController
  def root
    render :root
  end
end
